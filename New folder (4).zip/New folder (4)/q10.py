def convert_to_uppercase(input_string):
    return input_string.upper()

string = input("Enter a string: ")
uppercase_string = convert_to_uppercase(string)
print("Uppercase:", uppercase_string)
