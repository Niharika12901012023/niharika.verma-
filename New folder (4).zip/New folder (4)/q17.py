def convert_to_title_case(input_string):
    return input_string.title()

string = input("Enter a string: ")
title_case_string = convert_to_title_case(string)
print("Title case:", title_case_string)
