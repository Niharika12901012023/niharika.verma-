def greet():
    name = input("What's your name? ")
    print(f"Hello, {name}! Nice to meet you.")


greet()
