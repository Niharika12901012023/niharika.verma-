def string_to_list(string):
    return [char for char in string]

input_string = "Hello World"
characters_list = string_to_list(input_string)
print("String converted to list of characters:", characters_list)
