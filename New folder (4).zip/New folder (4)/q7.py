def string_length(string):
    return len(string)


user_input = input("Enter a string: ")


length = string_length(user_input)


print(f"The length of the string is: {length}")
